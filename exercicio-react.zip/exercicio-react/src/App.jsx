import { useState } from 'react';

function App() {
  const [peso, setPeso] = useState(0);
  const [altura, setAltura] = useState(0);
  const [imc, setImc] = useState(0);

  const calcularIMC = () => {
    const alturaMetros = altura / 100;
    const imc = peso / (alturaMetros * alturaMetros);
    setImc(imc.toFixed(2));
  };

  return (
    <div>
      <h1>Calculadora de IMC</h1>
      <label>
        Peso (kg):
        <input type="number" value={peso} onChange={e => setPeso(e.target.value)} />
      </label>
      <label>
        Altura (cm):
        <input type="number" value={altura} onChange={e => setAltura(e.target.value)} />
      </label>
      <button onClick={calcularIMC}>Calcular</button>
      <p>O seu IMC é: {imc}</p>
    </div>
  );
}

export default App;
